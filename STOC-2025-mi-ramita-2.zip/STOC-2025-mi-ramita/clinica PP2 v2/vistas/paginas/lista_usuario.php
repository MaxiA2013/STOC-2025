<?php
require_once "modelos/usuarios.php";
$is_admin = isset($_SESSION['nombre_perfil']) && $_SESSION['nombre_perfil'] === 'Administrador';

$con = new Usuario("", "", "", "", "");
$lista_usuarios = $con->all_usuarios();
?>

<div class="py-5 container">
    <h2>Lista de Usuarios</h2>
    <div class="row">
        <div class="col">
            <form method="POST" action="controladores/login.controlador.php">
                <input type="hidden" name="action" value="registro" />

                <!-- Campos comunes -->
                <div class="mb-3 mt-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" id="nombre" placeholder="Ingrese el Nombre" name="nombre" required>
                </div>
                <div class="mb-3 mt-3">
                    <label for="apellido" class="form-label">Apellido</label>
                    <input type="text" class="form-control" id="apellido" placeholder="Ingrese el Apellido" name="apellido" required>
                </div>
                <div class="mb-3 mt-3">
                    <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento</label>
                    <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                </div>
                <div class="mb-3 mt-3">
                    <label for="sexo" class="form-label">Sexo</label>
                    <select class="form-select" id="sexo" name="sexo" required>
                        <option value="1">Masculino</option>
                        <option value="2">Femenino</option>
                        <option value="3">Otro</option>
                    </select>
                </div>
                <div class="mb-3 mt-3">
                    <label for="nombre_usuario" class="form-label">Nombre Usuario</label>
                    <input type="text" onfocusout="validate_nombre_usuario(event)" class="form-control" id="nombre_usuario" name="nombre_usuario" placeholder="Ingrese el nombre del usuario" required>
                </div>
                <div class="mb-3 mt-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" onfocusout="validate_email()" class="form-control" id="email" name="email" placeholder="Ingresar Correo Electrónico" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña:</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Ingresar Contraseña" required>
                </div>

                <!-- Mostrar selector de perfil si es admin -->
                <?php if ($is_admin): ?>
                    <div class="mb-3 mt-3">
                        <label for="perfil" class="form-label">Perfil</label>
                        <select class="form-select" id="perfil" name="perfil_id_perfil" onchange="toggleDoctorFields()">
                            <option value="2">Administrador</option>
                            <option value="3">Doctor</option>
                            <option value="1" selected>Paciente</option>
                        </select>
                    </div>

                    <!-- Campos adicionales para Doctor -->
                    <div id="doctorFields" style="display: none;">
                        <div class="mb-3 mt-3">
                            <label for="matricula" class="form-label">Número de Matrícula Profesional</label>
                            <input type="text" class="form-control" id="matricula" name="numero_matricula_profesional" placeholder="Ingrese la matrícula">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="salario" class="form-label">Salario</label>
                            <input type="number" class="form-control" id="salario" name="salario" placeholder="Ingrese el salario" step="0.01">
                        </div>
                    </div>
                <?php else: ?>
                    <input type="hidden" name="perfil_id_perfil" value="3">
                <?php endif; ?>

                <div class="form-check mb-3">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" name="remember"> Recordar Contraseña
                    </label>
                </div>

                <button type="submit" class="btn btn-primary">Guardar</button>
            </form>
        </div>

        <!-- Tabla de usuarios -->
        <div class="col">
            <form class="row g-3">
                <div class="col-auto">
                    <input type="text" class="form-control" placeholder="Buscar...">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary mb-3">Buscar</button>
                </div>
            </form>

            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>username</th>
                        <th>email</th>
                        <th>nombre</th>
                        <th>apellido</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($lista_usuarios as $row): ?>
                        <tr>
                            <td><?= $row['id_usuario'] ?></td>
                            <td><?= $row['nombre_usuario'] ?></td>
                            <td><?= $row['email'] ?></td>
                            <td><?= $row['nombre'] ?></td>
                            <td><?= $row['apellido'] ?></td>
                            <td>
                                <!-- Eliminar -->
                                <form action="controladores/usuarios/usuarios_controlador.php" method="post" style="display:inline">
                                    <input type="hidden" name="id_usuario" value="<?= $row['id_usuario'] ?>">
                                    <input type="hidden" name="action" value="eliminacion">
                                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-delete-left"></i></button>
                                </form>
                                <!-- Modificar -->
                                <a href="controladores/usuarios/editar_usuario.php?id_usuario=<?= $row['id_usuario']; ?>"
                                class="btn btn-warning"
                                onclick="return confirm('¿Quieres modificar los datos de este usuario?')">
                                    <i class="fa-solid fa-pen-nib"></i>
                                </a>

                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

            <nav aria-label="...">
                <ul class="pagination">
                    <li class="page-item">
                        <a class="page-link">Anterior</a>
                    </li>

                    <li class="page-item">
                        <a class="page-link" href="#">Siguiente</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
    </div>
</div>

<?php if ($is_admin): ?>
<script>
    function toggleDoctorFields() {
        var perfil = document.getElementById("perfil").value;
        var camposDoctor = document.getElementById("doctorFields");
        camposDoctor.style.display = (perfil == "2") ? "block" : "none";
    }
    window.onload = toggleDoctorFields;
</script>
<?php endif; ?>

<script src="assets/js/validaciones/usuarios.js"></script>
