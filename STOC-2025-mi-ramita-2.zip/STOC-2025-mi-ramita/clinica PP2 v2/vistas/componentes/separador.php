<style>
    .b-example-divider{
        margin: 10px;
        padding: 20px;
    }
</style>

<div class="b-example-divider"></div>