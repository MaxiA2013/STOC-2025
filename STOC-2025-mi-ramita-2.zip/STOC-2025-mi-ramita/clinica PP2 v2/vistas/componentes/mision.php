<style>
    .container.col-xxl-8.px-4.py-5{
        background-color: chocolate;
        padding: 20px;
        justify-content: center;
    }

    .row.flex-lg-row-reverse{
        background-color: cornflowerblue;
    }

    img{
        width: 100%;
        height: auto;
        object-fit: cover;
        margin-bottom: 20px;
    }

</style>

<div class="container col-xxl-8 px-4 py-5">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
        <div class="col-10 col-sm-8 col-lg-6">
            <img src="../../assets/images/6511c213dadb6.jpg" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="700" height="500" loading="lazy">
        </div>
        <div class="col-lg-6">
            <h1 class="display-5 fw-bold text-body-emphasis lh-1 mb-3">Mision</h1>
            <ca class="lead">Estamos comprometidos con brindarle la mejor atencion, buscamos liderar a nivel regional la medicina con la ayuda de nuestros socios.</p>
        </div>
    </div>
</div>