<style>
    .container.col-xxl-8.px-4.py-5 {
        background-color: #8999AE;
        margin: 0px auto;
        padding: 20px;
        border-radius: 20px;
    }

    .col-10.col-sm-8.col-lg-6 {
        background-color: rgb(50, 148, 201);
        border-radius: 10px;
        margin: 0px auto;
        padding: 20px;
    }
</style>

<div class="container text-center">
  <div class="row align-items-center">
    <div class="col">
      One of three columns
    </div>
    <div class="col">
      One of three columns
    </div>
  </div>
  
</div>
