<?php

class PlantillaControlador{
    public function traer_plantilla(){
        return include 'vistas/plantilla.php';
    }
}

?>