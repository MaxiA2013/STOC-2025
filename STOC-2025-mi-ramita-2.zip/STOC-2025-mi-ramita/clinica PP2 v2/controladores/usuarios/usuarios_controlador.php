<?php
require_once "../../modelos/persona.php";
require_once "../../modelos/usuarios.php";

if (isset($_POST['action'])) {
    $accion = $_POST['action'];

    switch ($accion) {

        case 'insertar':
            // Primero guardamos la persona
            $persona = new Persona();
            $persona->setNombre($_POST['nombre']);
            $persona->setApellido($_POST['apellido']);
            $persona->setSexo($_POST['sexo']);
            $persona->setFecha_nacimiento($_POST['fecha_nacimiento']);
            $id_persona = $persona->guardar();

            // Ahora guardamos el usuario
            $usuario = new Usuario();
            $usuario->setNombre_usuario($_POST['nombre_usuario']);
            $usuario->setEmail($_POST['email']);
            $usuario->setPassword($_POST['password']);
            $usuario->setPersona_id_persona($id_persona);
            $usuario->guardarUsuario();

            header('Location: ../../index.php?page=lista_usuario');
            break;

        case 'eliminacion':
            $usuario = new Usuario();
            $usuario->setId_usuario($_POST['id_usuario']);
            $usuario->eliminar();
            header('Location: ../../index.php?page=lista_usuario');
            break;

case 'actualizacion':
    if (empty($_POST['persona_id_persona'])) {
        die("Error: persona_id_persona no definido o vacío.");
    }

    // 1. Actualiza persona
    $persona = new Persona();
    $persona->setId_persona($_POST['persona_id_persona']);
    $persona->setNombre($_POST['nombre']);
    $persona->setApellido($_POST['apellido']);
    $persona->setSexo($_POST['sexo']);
    $persona->setFecha_nacimiento($_POST['fecha_nacimiento']);
    $persona->actualizar();

    // 2. Actualiza usuario
    $usuario = new Usuario();
    $usuario->setId_usuario($_POST['id_usuario']);
    $usuario->setNombre_usuario($_POST['nombre_usuario']);
    $usuario->setEmail($_POST['email']);
    $usuario->setPersona_id_persona($_POST['persona_id_persona']);

    if (!empty($_POST['password'])) {
        $usuario->setPassword($_POST['password']);
    } else {
        $res = $usuario->traer_usuario_por_id();
        $fila = $res->fetch_assoc();
        $usuario->setPassword($fila['password']);
    }
    $usuario->actualizarUsuario();

    header('Location: ../../index.php?page=lista_usuario');
    break;
    }
}
