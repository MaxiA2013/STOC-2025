<?php
require_once "../../modelos/usuarios.php";


$is_admin = isset($_SESSION['nombre_perfil']) && $_SESSION['nombre_perfil'] === 'Administrador';

if (!isset($_GET['id_usuario'])) { die("ID de usuario no especificado."); }

$usuario = new Usuario();
$usuario->setId_usuario($_GET['id_usuario']);
$resultado = $usuario->traer_usuario_por_id();

if (!$resultado || $resultado->num_rows === 0) { die("Usuario no encontrado."); }

$u = $resultado->fetch_assoc();
?>

<div class="py-5 container">
    <h2>Editar Usuario</h2>
    <form method="POST" action="../../controladores/usuarios/usuarios_controlador.php">
        <input type="hidden" name="action" value="actualizacion">
        <input type="hidden" name="id_usuario" value="<?= $u['id_usuario']; ?>">
        <input type="hidden" name="persona_id_persona" value="<?= $u['persona_id_persona']; ?>">

        <!-- Datos persona -->
        <div class="mb-3 mt-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre"
                   value="<?= htmlspecialchars($u['nombre']); ?>" required>
        </div>
        <div class="mb-3 mt-3">
            <label for="apellido" class="form-label">Apellido</label>
            <input type="text" class="form-control" id="apellido" name="apellido"
                   value="<?= htmlspecialchars($u['apellido']); ?>" required>
        </div>
        <div class="mb-3 mt-3">
            <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento</label>
            <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"
                   value="<?= $u['fecha_nacimiento']; ?>" required>
        </div>
        <div class="mb-3 mt-3">
            <label for="sexo" class="form-label">Sexo</label>
            <select class="form-select" id="sexo" name="sexo" required>
                <option value="1" <?= $u['sexo'] == '1' ? 'selected' : ''; ?>>Masculino</option>
                <option value="2" <?= $u['sexo'] == '2' ? 'selected' : ''; ?>>Femenino</option>
                <option value="3" <?= $u['sexo'] == '3' ? 'selected' : ''; ?>>Otro</option>
            </select>
        </div>

        <!-- Datos usuario -->
        <div class="mb-3 mt-3">
            <label for="nombre_usuario" class="form-label">Nombre Usuario</label>
            <input type="text" class="form-control" id="nombre_usuario" name="nombre_usuario"
                   value="<?= $u['nombre_usuario']; ?>" required>
        </div>
        <div class="mb-3 mt-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email"
                   value="<?= $u['email']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Contraseña</label>
            <input type="password" class="form-control" id="password" name="password"
                   placeholder="Dejar en blanco para no cambiar">
        </div>

        <?php if ($is_admin): ?>
            <div class="mb-3 mt-3">
                <label for="perfil" class="form-label">Perfil</label>
                <select class="form-select" id="perfil" name="perfil_id_perfil">
                    <option value="2" <?= $u['perfil_id_perfil'] == 2 ? 'selected' : ''; ?>>Administrador</option>
                    <option value="3" <?= $u['perfil_id_perfil'] == 3 ? 'selected' : ''; ?>>Doctor</option>
                    <option value="1" <?= $u['perfil_id_perfil'] == 1 ? 'selected' : ''; ?>>Paciente</option>
                </select>
            </div>
        <?php else: ?>
            <input type="hidden" name="perfil_id_perfil" value="<?= $u['perfil_id_perfil']; ?>">
        <?php endif; ?>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
